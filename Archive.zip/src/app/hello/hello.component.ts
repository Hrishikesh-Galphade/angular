import { Component, ElementRef, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-hello',
  templateUrl: './hello.component.html',
  styleUrls: ['./hello.component.css']
})
export class HelloComponent {

  @ViewChild('f') loginForm:NgForm

  title:string="In a Hello Component"
  isUserLoggedIn :boolean = false;

  PrintTitle(){
    console.log(this.title);
    setTimeout(()=>{
      this.title = "Calling after 5 sec"
    },5000)
  }

  printTitaleAgain(){
    this.PrintTitle();
  }

  calculateLengthOfTitle(){
    return this.title.length;
  }

  onSubmit(form:NgForm){
    console.log(form.value);
  }

  onLocalReferenceSubmit(){
    console.log(this.loginForm);
  }
}
